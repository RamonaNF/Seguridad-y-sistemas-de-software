//
//  RROApp.swift
//  RRO
//
//  Created by Ramona NF on 30/10/23.
//

import SwiftUI

@main
struct RROApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
